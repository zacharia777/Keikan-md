# 📱 Maxlabmobile Services Operations Group

## 🧭 Overview
The **Maxlabmobile Services Operations Group** ensures that all backend integrations, developer platforms, and cloud services supporting the Maxlabmobile suite of apps run securely, efficiently, and with maximum uptime.  

> **Group Owner:** Jim Aloo Juma  
> **Slack Channel:** `#wg-maxlabmobile_services`  
> **Meeting time:** `Thursday 9:30 GMT+0`

---

## 👥 Team Members

| Role | Name |
|------|------|
| **Group Owner** | Jim Aloo Juma |
| **Admin Accounts & Integrations** | Greg |
| **Backend Engineer** | Edwin |
| **Quality Assurance** | Vladimir |
| **Business Analyst** | Paul |

---

## 🎯 Purpose
To manage, secure, and maintain the external and cloud-based services supporting the Maxlabmobile suite of apps, ensuring high availability, compliance, and efficient integration with platforms like Firebase, GCP, and Azure AD.

---

## 🏆 Goals
- Maintain active, secure access to all developer service accounts (GCP, Firebase, Yahoo/AOL Dev, Azure AD)  
- Ensure proper integration and service continuity across all **six Maxlabmobile apps**  
- Monitor usage quotas, billing, and credentials to avoid service disruption  
- Document and automate service configurations where possible  

---

## ⚡ Triggers
- Launch or update of any Maxlabmobile app  
- Credential or API key rotation requirements  
- Security incidents or platform policy changes  
- Expiry or billing notices from integrated service providers  

---

## 📈 Outcomes
- Up-to-date service credentials and configurations  
- Compliance with security, privacy, and platform-specific guidelines  
- Detailed service usage and audit documentation  
- Actionable reports or alerts for service changes or outages  

---

## 🧰 Tools & Technologies

| Category | Tools |
|-----------|-------|
| **Mobile Stack** | Kotlin, Java, JavaMail, Gradle, Android Studio |
| **Backend & Cloud** | Firebase, Google Cloud Platform (GCP), Azure AD, Yahoo & AOL Developer APIs | Elixir
| **CI/CD** | GitLab CI, GitHub Actions |
| **Monitoring & QA** | Firebase Crashlytics, Play Console, Test Lab |
| **Documentation & Knowledge Base** | Markdown, OpenAPI, OneDrive |
| **Version Control** | GitLab — [Repo Link](https://gitlab.yoonka.com/yoonka/maxlabmobile-mailapp) |

---

## 📦 Product Suite (Hardcoded Metadata)

Explore our app ecosystem at [**maxlabmobile.com**](https://maxlabmobile.com/)

| Application | Description | Last Update | Installs | Rating | Link |
|--------------|-------------|--------------|-----------|--------|------|
| **eNotify** | Email + SMS notifications with smart filtering | Jul 30, 2025 | 5K+ | ⭐ 4.1 | [Play Store](https://play.google.com/store/apps/details?id=com.hermes.enotify) |
| **eNotify Lite** | Lightweight email alerting tool with advanced rules | Jul 29, 2025 | 50K+ | ⭐ 3.9 | [Play Store](https://play.google.com/store/apps/details?id=com.hermes.enotifylite) |
| **AutoReply OoO Lite** | Smart out-of-office and automated email response system | Aug 1, 2025 | 50K+ | ⭐ 4.2 | [Play Store](https://play.google.com/store/apps/details?id=com.maxlab.autoreply) |
| **Email Popup: Poppy** | Lightweight popup interface for quick email management | Jul 10, 2025 | 10K+ | ⭐ 4.3 | [Play Store](https://play.google.com/store/apps/details?id=com.maxlab.popupemail) |
| **Spam Blocker** | Intelligent email filtering with smart notifications | Jun 15, 2025 | 100K+ | ⭐ 4.5 | [Play Store](https://play.google.com/store/apps/details?id=com.maxlab.spamblocker) |
| **VoiceMail Notifier** | Text-to-speech email reading for hands-free operation | May 25, 2025 | 5K+ | ⭐ 4.1 | [Play Store](https://play.google.com/store/apps/details?id=com.maxlab.voicemailspeech) |
| **Email → SMS Gateway** | Seamless email-to-SMS conversion and delivery | May 20, 2025 | 10K+ | ⭐ 4.0 | [Play Store](https://play.google.com/store/apps/details?id=com.maxlab.emailsms) |

---

> 🧾 *Note: These figures are based on the latest internal tracking snapshot and may vary slightly from public Play Store metrics.*
---

## 🧩 Artifacts Maintained
- Service credential documentation and expiry trackers  
- Firebase, GCP, Azure AD, Yahoo/AOL API references  
- Access logs, configuration backups, and audit checklists  
- Onboarding guides for working with third-party APIs  

---

## 🗣 Communication
- **Slack:** `#wg-maxlabmobile_services`  
- **Email:** support@maxlabmobile.com  
- **Repository:** [GitLab Repository](https://gitlab.yoonka.com/yoonka/maxlabmobile-mailapp)  
- **Website:** [maxlabmobile.com](https://maxlabmobile.com/)

---

> 🧾 *This page serves as the central reference for Maxlabmobile’s service operations group — ensuring continuity, accountability, and transparency across all product environments.*